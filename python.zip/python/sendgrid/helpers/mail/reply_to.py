from .email import Email


class ReplyTo(Email):
    """A reply to email address with an optional name."""
